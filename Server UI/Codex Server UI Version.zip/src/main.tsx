import React, { useEffect, useMemo, useState } from 'react'
import ReactDOM from 'react-dom/client'
import './styles.css'

type ProviderOption = { id: string; label: string; description: string }
type ProviderGroup = 'compute' | 'database' | 'storage'

type ConnectionProfile = {
  label: string
  baseUrl: string
  adminKey: string
  computeProvider: string
  databaseProvider: string
  storageProvider: string
}

type ProvidersResponse = {
  compute?: ProviderMeta
  database?: ProviderMeta
  storage?: ProviderMeta
}

type ProviderMeta = {
  provider: string
  label: string
  engine?: string
  service?: string
  revision?: string
  region?: string
  host?: string
  root?: string
  supports?: Record<string, boolean>
  links?: Record<string, string>
}

const STORAGE_KEY = 'bidmanager.admin.profile.v1'

const PROVIDER_OPTIONS: Record<ProviderGroup, ProviderOption[]> = {
  compute: [
    { id: 'google-cloud-run', label: 'Google Cloud Run', description: 'Serverless container backend on Google Cloud.' },
    { id: 'railway', label: 'Railway', description: 'Always-on app hosting with managed services.' },
    { id: 'render', label: 'Render', description: 'Web service hosting with simple Git deploys.' },
    { id: 'custom-api', label: 'Custom API', description: 'Any FastAPI-compatible BidManager backend.' },
  ],
  database: [
    { id: 'neon-postgres', label: 'Neon Postgres', description: 'Serverless Postgres with a generous free tier.' },
    { id: 'supabase-postgres', label: 'Supabase Postgres', description: 'Postgres plus managed platform features.' },
    { id: 'cloud-sql', label: 'Cloud SQL', description: 'Google-managed Postgres for paid production workloads.' },
    { id: 'railway-postgres', label: 'Railway Postgres', description: 'Railway-hosted Postgres near the app.' },
    { id: 'custom-postgres', label: 'Custom Postgres', description: 'Any Postgres URL kept on the backend.' },
  ],
  storage: [
    { id: 'google-drive', label: 'Google Drive', description: 'Drive folder storage through backend service account.' },
    { id: 'cloud-storage', label: 'Cloud Storage', description: 'Object bucket storage for cloud-native files.' },
    { id: 's3-r2', label: 'S3 / R2', description: 'AWS S3 or Cloudflare R2 compatible storage.' },
    { id: 'local-volume', label: 'Local / Volume', description: 'Local disk or persistent volume fallback.' },
  ],
}

const DEFAULT_PROFILE: ConnectionProfile = {
  label: 'Production',
  baseUrl: 'http://127.0.0.1:8000',
  adminKey: '',
  computeProvider: 'google-cloud-run',
  databaseProvider: 'neon-postgres',
  storageProvider: 'google-drive',
}

function loadProfile(): ConnectionProfile {
  try {
    return { ...DEFAULT_PROFILE, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') }
  } catch {
    return DEFAULT_PROFILE
  }
}

async function api<T>(profile: ConnectionProfile, path: string, init: RequestInit = {}): Promise<T> {
  const baseUrl = profile.baseUrl.replace(/\/+$/, '')
  const response = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers: {
      'content-type': 'application/json',
      'x-admin-key': profile.adminKey,
      ...(init.headers || {}),
    },
  })
  if (!response.ok) {
    const text = await response.text()
    throw new Error(text || `${response.status} ${response.statusText}`)
  }
  return response.json() as Promise<T>
}

function selectedLabel(group: ProviderGroup, value: string): string {
  return PROVIDER_OPTIONS[group].find((option) => option.id === value)?.label || value
}

function App() {
  const [profile, setProfile] = useState(loadProfile)
  const [activeTab, setActiveTab] = useState('overview')
  const [toast, setToast] = useState('')

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile))
  }, [profile])

  const client = useMemo(() => ({ api: <T,>(path: string, init?: RequestInit) => api<T>(profile, path, init) }), [profile])

  function notify(message: string) {
    setToast(message)
    window.setTimeout(() => setToast(''), 3500)
  }

  const tabs = [
    ['overview', 'Overview'],
    ['config', 'Config'],
    ['jobs', 'Jobs'],
    ['captchas', 'Captchas'],
    ['storage', 'Files'],
    ['database', 'Database'],
    ['logs', 'Logs'],
  ]

  return (
    <main className="shell">
      <header className="hero">
        <div>
          <p className="eyebrow">BidManager Cloud Admin</p>
          <h1>Provider-agnostic control room</h1>
          <p className="muted">
            Current target: {selectedLabel('compute', profile.computeProvider)} + {selectedLabel('database', profile.databaseProvider)} + {selectedLabel('storage', profile.storageProvider)}.
          </p>
        </div>
        {toast && <div className="toast">{toast}</div>}
      </header>

      <ConnectionSetup profile={profile} setProfile={setProfile} client={client} notify={notify} />

      <nav className="tabs">
        {tabs.map(([id, label]) => (
          <button key={id} className={activeTab === id ? 'active' : ''} onClick={() => setActiveTab(id)}>
            {label}
          </button>
        ))}
      </nav>

      {activeTab === 'overview' && <OverviewPanel profile={profile} client={client} notify={notify} />}
      {activeTab === 'config' && <ConfigPanel client={client} notify={notify} />}
      {activeTab === 'jobs' && <JobsPanel client={client} notify={notify} />}
      {activeTab === 'captchas' && <CaptchaPanel client={client} notify={notify} />}
      {activeTab === 'storage' && <StoragePanel client={client} notify={notify} />}
      {activeTab === 'database' && <DatabasePanel client={client} />}
      {activeTab === 'logs' && <LogsPanel client={client} profile={profile} />}
    </main>
  )
}

function ConnectionSetup({
  profile,
  setProfile,
  client,
  notify,
}: {
  profile: ConnectionProfile
  setProfile: React.Dispatch<React.SetStateAction<ConnectionProfile>>
  client: { api: <T>(path: string, init?: RequestInit) => Promise<T> }
  notify: (message: string) => void
}) {
  async function testConnection() {
    const response = await client.api<{ providers: ProvidersResponse; status: string }>('/admin/health')
    setProfile((current) => ({
      ...current,
      computeProvider: response.providers.compute?.provider || current.computeProvider,
      databaseProvider: response.providers.database?.provider || current.databaseProvider,
      storageProvider: response.providers.storage?.provider || current.storageProvider,
    }))
    notify(`Connected: ${response.status}`)
  }

  return (
    <section className="card grid">
      <Field label="Profile label" value={profile.label} onChange={(label) => setProfile((p) => ({ ...p, label }))} />
      <Field label="Backend URL" value={profile.baseUrl} onChange={(baseUrl) => setProfile((p) => ({ ...p, baseUrl }))} placeholder="https://your-service.a.run.app" />
      <Field label="Admin key" type="password" value={profile.adminKey} onChange={(adminKey) => setProfile((p) => ({ ...p, adminKey }))} />
      <ProviderSelect group="compute" value={profile.computeProvider} onChange={(computeProvider) => setProfile((p) => ({ ...p, computeProvider }))} />
      <ProviderSelect group="database" value={profile.databaseProvider} onChange={(databaseProvider) => setProfile((p) => ({ ...p, databaseProvider }))} />
      <ProviderSelect group="storage" value={profile.storageProvider} onChange={(storageProvider) => setProfile((p) => ({ ...p, storageProvider }))} />
      <div className="actions">
        <button onClick={testConnection}>Test & sync providers</button>
      </div>
    </section>
  )
}

function ProviderSelect({ group, value, onChange }: { group: ProviderGroup; value: string; onChange: (value: string) => void }) {
  return (
    <label>
      <span>{group[0].toUpperCase() + group.slice(1)} provider</span>
      <select value={value} onChange={(event) => onChange(event.target.value)}>
        {PROVIDER_OPTIONS[group].map((option) => (
          <option key={option.id} value={option.id}>{option.label}</option>
        ))}
      </select>
      <small>{PROVIDER_OPTIONS[group].find((option) => option.id === value)?.description}</small>
    </label>
  )
}

function Field({ label, value, onChange, placeholder = '', type = 'text' }: { label: string; value: string; onChange: (value: string) => void; placeholder?: string; type?: string }) {
  return (
    <label>
      <span>{label}</span>
      <input type={type} value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} />
    </label>
  )
}

function OverviewPanel({ profile, client, notify }: { profile: ConnectionProfile; client: { api: <T>(path: string, init?: RequestInit) => Promise<T> }; notify: (message: string) => void }) {
  const [health, setHealth] = useLoad<Record<string, unknown>>(() => client.api('/admin/health'), [client])
  const providers = (health?.providers || {}) as ProvidersResponse

  async function serverAction(action: string) {
    await client.api(`/admin/server/${action}`, { method: 'POST', body: '{}' })
    notify(`${action} sent`)
  }

  return (
    <section className="panel">
      <Card title="Backend">
        <Metric label="Status" value={String(health?.status || 'unknown')} />
        <Metric label="Provider" value={providers.compute?.label || selectedLabel('compute', profile.computeProvider)} />
        <Metric label="Revision" value={String(providers.compute?.revision || 'n/a')} />
        <div className="actions">
          <button onClick={() => serverAction('pause-scheduler')}>Pause/resume scheduler</button>
          <button onClick={() => serverAction('drain')}>Drain queue</button>
          <button className="danger" onClick={() => serverAction('restart')}>Restart</button>
        </div>
        <p className="hint">Restart/redeploy intentionally returns “not supported” in v1 unless a provider adapter adds IAM-safe support.</p>
      </Card>
      <Card title="Providers">
        <ProviderMetaView title="Compute" meta={providers.compute} />
        <ProviderMetaView title="Database" meta={providers.database} />
        <ProviderMetaView title="Files" meta={providers.storage} />
      </Card>
    </section>
  )
}

function ConfigPanel({ client, notify }: { client: { api: <T>(path: string, init?: RequestInit) => Promise<T> }; notify: (message: string) => void }) {
  const [config, setConfig] = useLoad<{ settings: Record<string, unknown> }>(() => client.api('/admin/config'), [client])
  const settings = config?.settings || {}

  function update(key: string, value: string) {
    setConfig((current) => ({ settings: { ...(current?.settings || {}), [key]: value } }))
  }

  async function save() {
    const response = await client.api<{ settings: Record<string, unknown> }>('/admin/config', {
      method: 'PUT',
      body: JSON.stringify({ settings }),
    })
    setConfig(response)
    notify('Config saved')
  }

  return (
    <section className="card">
      <div className="section-head"><h2>Runtime config</h2><button onClick={save}>Save config</button></div>
      <div className="config-grid">
        {Object.entries(settings).map(([key, value]) => (
          <Field key={key} label={key} value={String(value)} onChange={(next) => update(key, next)} />
        ))}
      </div>
    </section>
  )
}

function JobsPanel({ client, notify }: { client: { api: <T>(path: string, init?: RequestInit) => Promise<T> }; notify: (message: string) => void }) {
  const [jobs, setJobs] = useLoad<{ jobs: Array<Record<string, unknown>> }>(() => client.api('/admin/jobs'), [client])

  async function action(jobId: unknown, kind: string) {
    await client.api(`/admin/jobs/${jobId}/${kind}`, { method: 'POST', body: '{}' })
    setJobs(await client.api('/admin/jobs'))
    notify(`${kind} requested`)
  }

  async function purge() {
    await client.api('/admin/jobs/purge', { method: 'POST', body: '{}' })
    setJobs(await client.api('/admin/jobs'))
    notify('Finished jobs purged')
  }

  return (
    <section className="card">
      <div className="section-head"><h2>Jobs</h2><button onClick={purge}>Purge finished</button></div>
      <Table rows={jobs?.jobs || []} columns={['id', 'action', 'status', 'error']} actions={(row) => (
        <>
          <button onClick={() => action(row.id, 'cancel')}>Cancel</button>
          <button onClick={() => action(row.id, 'retry')}>Retry</button>
        </>
      )} />
    </section>
  )
}

function CaptchaPanel({ client, notify }: { client: { api: <T>(path: string, init?: RequestInit) => Promise<T> }; notify: (message: string) => void }) {
  const [answer, setAnswer] = useState('')
  const [data, setData] = useLoad<{ captchas: Array<Record<string, unknown>> }>(() => client.api('/admin/captchas/pending'), [client])
  const active = data?.captchas?.[0]

  async function submit() {
    if (!active) return
    await client.api(`/admin/captchas/${active.id}/answer`, { method: 'POST', body: JSON.stringify({ answer }) })
    setAnswer('')
    setData(await client.api('/admin/captchas/pending'))
    notify('Captcha answer sent')
  }

  async function skip() {
    if (!active) return
    await client.api(`/admin/captchas/${active.id}/skip`, { method: 'POST', body: JSON.stringify({ action: 'requeue' }) })
    setData(await client.api('/admin/captchas/pending'))
    notify('Captcha skipped')
  }

  return (
    <section className="card">
      <h2>Manual captcha handover</h2>
      {!active && <p className="muted">No captcha is waiting right now. Tiny mercy from the portals.</p>}
      {active && (
        <div className="captcha-box">
          <img src={String(active.image)} alt="Pending captcha" />
          <Field label="Captcha answer" value={answer} onChange={setAnswer} />
          <div className="actions"><button onClick={submit}>Submit</button><button onClick={skip}>Skip</button></div>
        </div>
      )}
    </section>
  )
}

function StoragePanel({ client, notify }: { client: { api: <T>(path: string, init?: RequestInit) => Promise<T> }; notify: (message: string) => void }) {
  const [prefix, setPrefix] = useState('')
  const [data, setData] = useLoad<Record<string, unknown>>(() => client.api(`/admin/storage?prefix=${encodeURIComponent(prefix)}`), [client, prefix])
  const [usage] = useLoad<Record<string, unknown>>(() => client.api('/admin/storage/usage'), [client])
  const folders = (data?.folders || []) as Array<Record<string, unknown>>
  const files = (data?.files || []) as Array<Record<string, unknown>>

  return (
    <section className="panel">
      <Card title="Storage">
        <Metric label="Provider" value={String(data?.label || data?.provider || 'unknown')} />
        <Metric label="Objects" value={String(usage?.objects ?? 'n/a')} />
        <Metric label="Used" value={formatBytes(usage?.usedBytes as number | null)} />
        <Field label="Prefix/path" value={prefix} onChange={setPrefix} />
        <button onClick={() => notify('Create/delete/link actions need provider-specific adapters after v1.')}>Provider action</button>
      </Card>
      <Card title="Files">
        <Table rows={[...folders, ...files]} columns={['name', 'path', 'sizeBytes', 'modified']} />
      </Card>
    </section>
  )
}

function DatabasePanel({ client }: { client: { api: <T>(path: string, init?: RequestInit) => Promise<T> } }) {
  const [stats] = useLoad<Record<string, unknown>>(() => client.api('/admin/db/stats'), [client])
  return (
    <section className="panel">
      <Card title="Database">
        <Metric label="Provider" value={String(stats?.label || stats?.provider || 'unknown')} />
        <Metric label="Engine" value={String(stats?.engine || 'unknown')} />
        <Metric label="Host" value={String(stats?.host || 'n/a')} />
        <Metric label="Size" value={formatBytes(stats?.sizeBytes as number | null)} />
      </Card>
      <Card title="Tables">
        <Table rows={(stats?.tables || []) as Array<Record<string, unknown>>} columns={['name', 'rows', 'sizeBytes']} />
      </Card>
    </section>
  )
}

function LogsPanel({ client, profile }: { client: { api: <T>(path: string, init?: RequestInit) => Promise<T> }; profile: ConnectionProfile }) {
  const [lines, setLines] = useState<string[]>([])

  useEffect(() => {
    let cancelled = false
    let sinceSeq = 0
    async function poll() {
      try {
        const response = await client.api<{ lines: string[]; next_seq: number }>(`/admin/logs/live?since_seq=${sinceSeq}`)
        sinceSeq = response.next_seq
        if (!cancelled && response.lines.length) {
          setLines((current) => [...current, ...response.lines].slice(-300))
        }
      } catch (error) {
        if (!cancelled) setLines((current) => [...current, `Log polling failed: ${(error as Error).message}`].slice(-300))
      }
    }
    poll()
    const timer = window.setInterval(poll, 3000)
    return () => {
      cancelled = true
      window.clearInterval(timer)
    }
  }, [client, profile.baseUrl, profile.adminKey])

  return (
    <section className="card">
      <h2>Live logs</h2>
      <pre className="logs">{lines.join('\n') || 'Waiting for backend logs...'}</pre>
    </section>
  )
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="card"><h2>{title}</h2>{children}</section>
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div className="metric"><span>{label}</span><strong>{value}</strong></div>
}

function ProviderMetaView({ title, meta }: { title: string; meta?: ProviderMeta }) {
  return (
    <div className="provider-meta">
      <strong>{title}</strong>
      <span>{meta?.label || 'Not synced'}</span>
      <small>{meta?.provider || 'Connect to backend to detect provider'}</small>
    </div>
  )
}

function Table({ rows, columns, actions }: { rows: Array<Record<string, unknown>>; columns: string[]; actions?: (row: Record<string, unknown>) => React.ReactNode }) {
  if (!rows.length) return <p className="muted">No rows to show.</p>
  return (
    <div className="table-wrap">
      <table>
        <thead><tr>{columns.map((column) => <th key={column}>{column}</th>)}{actions && <th>actions</th>}</tr></thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={String(row.id || row.path || row.name || index)}>
              {columns.map((column) => <td key={column}>{formatCell(row[column])}</td>)}
              {actions && <td className="row-actions">{actions(row)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function useLoad<T>(loader: () => Promise<T>, deps: React.DependencyList): [T | null, React.Dispatch<React.SetStateAction<T | null>>] {
  const [data, setData] = useState<T | null>(null)
  useEffect(() => {
    let cancelled = false
    loader().then((next) => {
      if (!cancelled) setData(next)
    }).catch((error) => {
      if (!cancelled) setData(({ error: (error as Error).message } as T))
    })
    return () => { cancelled = true }
  }, deps)
  return [data, setData]
}

function formatCell(value: unknown): string {
  if (typeof value === 'number' && /Bytes$/.test('sizeBytes')) return formatBytes(value)
  if (value === null || value === undefined || value === '') return '—'
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}

function formatBytes(value: number | null | undefined): string {
  if (typeof value !== 'number') return 'n/a'
  if (value < 1024) return `${value} B`
  const units = ['KB', 'MB', 'GB', 'TB']
  let size = value / 1024
  let unit = 0
  while (size >= 1024 && unit < units.length - 1) {
    size /= 1024
    unit += 1
  }
  return `${size.toFixed(1)} ${units[unit]}`
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
