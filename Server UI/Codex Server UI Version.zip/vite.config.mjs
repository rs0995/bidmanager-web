import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const frontendModules = path.resolve(__dirname, '../frontend/node_modules')

export default {
  plugins: [],
  resolve: {
    alias: {
      react: path.join(frontendModules, 'react'),
      'react-dom': path.join(frontendModules, 'react-dom'),
      'react/jsx-runtime': path.join(frontendModules, 'react/jsx-runtime.js'),
      'react-refresh': path.join(frontendModules, 'react-refresh'),
    },
  },
}
